MHT VIEWER — VERSI BISA DIPASANG DI ANDROID (PWA)
==================================================

Isi paket:
- index.html             Aplikasi MHT Viewer asli, dipertahankan
- manifest.webmanifest   Identitas dan tampilan aplikasi saat dipasang
- sw.js                  Cache aplikasi agar bisa dibuka offline
- icons/                 Ikon aplikasi 192 px dan 512 px

CARA MEMASANG DI ANDROID MELALUI GITHUB PAGES
--------------------------------------------
1. Ekstrak ZIP ini.
2. Masuk ke GitHub dan buat repository baru, misalnya: mht-viewer.
3. Unggah SEMUA isi folder ini ke bagian paling atas (root) repository.
   Pastikan index.html berada sejajar dengan manifest.webmanifest dan sw.js.
4. Buka Settings > Pages pada repository.
5. Pada Build and deployment, pilih Deploy from a branch.
6. Pilih branch main dan folder /(root), lalu tekan Save.
7. Setelah GitHub Pages menerbitkan situs, buka alamat HTTPS yang diberikan GitHub
   menggunakan Chrome di Android.
8. Tunggu halaman selesai dimuat. Ketuk tombol "⬇ Pasang" bila muncul.
   Bila tidak muncul, buka menu Chrome (⋮) lalu pilih "Install app"
   atau "Tambahkan ke layar utama".
9. Buka MHT Viewer dari ikon di layar utama. Setelah aplikasi selesai dimuat
   setidaknya sekali, cangkang aplikasinya dapat dibuka tanpa internet.

CATATAN PENTING
---------------
- Ini adalah PWA (Progressive Web App), bukan berkas APK.
- Pemasangan PWA membutuhkan alamat HTTPS (misalnya GitHub Pages).
  Membuka index.html langsung dari pengelola file tidak mengaktifkan instalasi/offline.
- File MHT/CBZ/gambar yang dibuka tetap dipilih dari penyimpanan perangkat.
  File-file pribadi tersebut tidak diunggah ke server oleh PWA ini.
- Cache offline menyimpan aplikasi, bukan koleksi file yang Anda buka.
- Fitur pemilihan, penggantian nama, atau penghapusan file bergantung pada dukungan
  browser dan izin penyimpanan Android.
